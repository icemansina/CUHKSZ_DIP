clc; clear all;
% Read membrane reference
mMRef = ReadMRC('mmRef.mrc');
mMslice = mMRef > 0;
mMmask = mMslice(30:end-30, 30:end-30,:);

% Read microtubule reference
mTRef = ReadMRC('mtRef.mrc');
mTslice = mTRef > 0;
mTmask = mTslice(30:end-30, 30:end-30,:);

% display the reference image
figure(1);clf;
subplot(1,2,1);
imshow(mMmask); 
subplot(1,2,2);
imshow(mTmask);

% Read raw image
img = ReadMRC('raw_tomo_slice.mrc');
slice = img(:,:,222);
imgGray = slice(30:end-30, 30:end-30,:);
% invert image 
imgInv = imcomplement(imgGray);
% binarize image
imgBN = imgInv > 0.95;               % threshold to consider

% display the raw image and binarize image
figure(2);clf;
subplot(1,2,1);
imshow(slice);
subplot(1,2,2);
imshow(imgBN);

% remove small regions 
se = strel('square',3);
imgerode = imerode(imgBN,se);
imgClean = bwareaopen(imgerode,150);         % threshold to consider
figure(3);clf;
imshow(imgClean);

% remove spurious edge of skeleton
% From https://www.mathworks.com/matlabcentral/answers/88284-remove-the-spurious-edge-of-skeleton
skel= bwmorph(imgClean,'skel',Inf);
B = bwmorph(skel, 'branchpoints');
E = bwmorph(skel, 'endpoints');
[y,x] = find(E);
B_loc = find(B);
Dmask = false(size(skel));
for k = 1:numel(x)
    D = bwdistgeodesic(skel,x(k),y(k));
    distanceToBranchPt = min(D(B_loc));
    Dmask(D < distanceToBranchPt) =true;
end
skelD = skel - Dmask; 
% display skeleton of features 
figure(4);
imshow(skelD);
hold on;

% calculate centroids and 'eccentricity' for region
CC = bwconncomp(skelD);
s = regionprops(CC, 'Orientation', 'MajorAxisLength', ...
     'MinorAxisLength', 'Eccentricity','Centroid','PixelList');
 
phi = linspace(0,2*pi,50);
cosphi = cos(phi);
sinphi = sin(phi);

% plot eclipse fit for each region
for k = 1:length(s)
    xbar = s(k).Centroid(1);
    ybar = s(k).Centroid(2);

    a = s(k).MajorAxisLength/2;
    b = s(k).MinorAxisLength/2;

    theta = pi*s(k).Orientation/180;
    R = [ cos(theta)   sin(theta)
         -sin(theta)   cos(theta)];

    xy = [a*cosphi; b*sinphi];
    xy = R*xy;

    x = xy(1,:) + xbar;
    y = xy(2,:) + ybar;

    plot(x,y,'y','LineWidth',2);
end

% test image dilation
se = strel('square',3);
imgClean = imdilate(imgClean,se);

% generate an output matrix for both features. 
[h,w] = size(imgBN);
OutCombine = imgClean;

% sort regions based on eccentricity of eclipses for each region
ecc = regionprops(CC,'Eccentricity');
eccentricity = cat(1,ecc.Eccentricity);
[eccSort,eccI] = sort(eccentricity,'descend');

    % microtubules  
mtInd = eccI(1:70);                % threshold to consider
mtSeeds = findseeds(s,mtInd);
plot(mtSeeds(:,1),mtSeeds(:,2),'r*', 'LineWidth', 2, 'MarkerSize', 15); 
[mtregions,idx] = bwselect(imgClean,mtSeeds(:,1),mtSeeds(:,2),4);
OutCombine = OutCombine + 2*mtregions;

    % membrane   
mmInd = eccI(end-130:end-30);      % threshold to consider
mmSeeds = findseeds(s,mmInd);
plot(mmSeeds(:,1),mmSeeds(:,2),'g+', 'LineWidth', 2, 'MarkerSize', 15); 
[mmregions,idx] = bwselect(imgClean,mmSeeds(:,1),mmSeeds(:,2),8);
OutCombine = OutCombine + 8* mmregions;

hold off;

% set unassigned pixels in the orignal binarized image to 5.
OutCombine(OutCombine == 1) = 5;
% trace membrane feature from binarized image
[grow,OutCombine] = growregion(OutCombine,4,mmSeeds,h,w,9);
% trace microtubule feature from binarized image
[grow,OutCombine] = growregion(OutCombine,2,mtSeeds,h,w,3);

% color two features
OutCombine(OutCombine == 5) = 0;
middleout = OutCombine > 0;
out = zeros(h,w,3);
out(:,:,1) = 255 * (OutCombine == 3);
out(:,:,2) = 255 * (OutCombine == 9);
figure(5);clf;
imshow(out);


% generage histomgram of regional eccentricity in the image
figure(6);clf;
hist(eccSort,50);
h = findobj(gca,'Type','patch');
h.FaceColor = [0 0.5 0.5];
h.EdgeColor = 'w';
xlabel('Eccentricity', 'FontSize', 10);
ylabel('Frequency', 'FontSize', 10);

figure(7);clf;

% evaluate accuracy of algorithm
% membrane detection
MM = out(:,:,2)> 0; 
MM = bwmorph(MM,'thicken');
[MMrecall, MMprecision] = evaluate_algorithm(MM,mMmask);
subplot(1,2,1);
imshow(MM);

% microtubule detection
MT = out(:,:,1) > 0; 
MT = bwmorph(MT,'thicken');
subplot(1,2,2);
imshow(MT);
[MTrecall, MTprecision] = evaluate_algorithm(MT,mTmask);


function [recall, precision] = evaluate_algorithm(out,Ref)
recall = sum(out .* Ref)/sum(Ref);
precision = sum(out .* Ref)/sum(out);
end


function seeds = findseeds(s,regionInd)
seeds = [];
for n = 1:length(regionInd)
    regionNum = regionInd(n);
    region = s(regionNum).PixelList;
    seeds = [seeds;region(floor(end/2+1),:)];
end
end


function [spur,OutCombine] = growregion(OutCombine,distance,seeds,h,w,feature)
spur = zeros(h,w);
for i = 1:size(seeds,1)
    r = seeds(i,1);
    c = seeds(i,2);
    if OutCombine(c,r) ~= 0
        bw = grayconnected(OutCombine,c,r,distance);
        spur = spur + bw;   
    end
end
OutCombine(spur > 0) = feature;
end
