Annotation of Microtubule and Membrane in Cell Tomography images
=================================
The dataset has one raw 2D tomogram slice, one ground truth image for microtubule and one ground truth image for membrane.

Files
-----
Root directory contains following files:
  - README.md                   
  - raw_tomo_slice.mrc          - this file
  - microtubuleRef.mrc          - ground truth for microtubule annotation
  - membraneRef.mrc             - ground truth for membrane annotation
  - code.m                      - code for annotation	


Installation
To read mrc file, you may have to add this package to your matlab. 
https://www.mathworks.com/matlabcentral/fileexchange/27021-imagic-mrc-dm-and-star-file-i-o

